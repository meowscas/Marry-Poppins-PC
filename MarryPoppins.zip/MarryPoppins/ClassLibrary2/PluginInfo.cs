﻿
namespace MarryPoppins
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    class PluginInfo
    {
        public const string GUID = "com.buzzbzzzbzzbzzzthe18th.gorillatag.marrypoppins";
        public const string Name = "MarryPoppins";
        public const string Version = "1.0.0";
    }
}
